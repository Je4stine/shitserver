<?php

/**
 * [curl(支持HTTP/HTTPS，GET/POST)]
 * @param     [string]     $url    [请求地址]
 * @param     [Array]      $data   [参数数据 array('name'=>'value')]
 * @return    [type]               [如果服务器返回xml则返回xml，不然则返回json]
 */
function curl($url, $data = [], $code = '')
{
    $config = include("config.php");
    $host = $config['service_url'];
    $headerkey = $config['secret_key'];
  

    $url = (string)$url;
    $url = $host . $url;
    output("\n $url ");
    $curl = curl_init();
//echo $url;
    $time = time();
    $header = array(
        'key:' . md5($headerkey . $time),
        'time:' . $time,
        'oCode:' . $code,
    );
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);


    if (!empty($data)) {//post方式
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }

    $output = curl_exec($curl);
    curl_close($curl);
    $json = json_decode($output, true);
//print_r($json);
    output("\n curl $url response:" . $output);
    return $json;
}


/**
 * 记录日志
 * @param  [str] $client_id  [连接ID]
 * @param  [str] $cabinet_id [机柜ID]
 * @param  [str] $type      [1为发送，2为接收]
 * @param  [str] $operation  [操作类型]
 * @param  [str] $message        [收到的原生字符串]
 * @param  [array] $data  [返回机柜的内容]
 * @return [type]            [description]
 */
function saveLog($client_id, $cabinet_id = null, $type, $operation, $message = null, $data = null)
{
    $time = time();
    $path = dirname(dirname(dirname(__FILE__))) . '/log/' . date('Ymd', $time);

    if (!is_dir($path)) {
        mkdir($path);
        mkdir($path . '/unknown');
    }
    if (is_array($client_id)) {
        $client_id = implode(',', $client_id);
    }
    if ($cabinet_id) {
        $filename = $path . '/' . $cabinet_id . '.log';
    } else {
        $filename = $path . '/unknown/' . $client_id . '.log';
    }

    $type == 1 ? $type = 'send' : $type = 'receive';

    is_array($message) && $message = json_encode($message, JSON_UNESCAPED_UNICODE);
    is_array($data) && $data = json_encode($data, JSON_UNESCAPED_UNICODE);

    $client_ip = $_SERVER['REMOTE_ADDR'];

    $content = date("Y-m-d H:i:s") . "\r\n";
    $content .= "client_id:" . $client_id . " , IP:$client_ip" . "\r\n";
    $content .= "type:" . $type . "\r\n";
    $content .= "operation:" . $operation . "\r\n";
    if ($message) {
        $content .= "receive:" . $message . "\r\n";
    }

    if ($data) {
        $content .= "send:" . $data . "\r\n";
    }
    $content .= "\r\n\r\n";
    file_put_contents($filename, $content, FILE_APPEND);
}


function output($content)
{
   // echo " {$content} ;";
}
