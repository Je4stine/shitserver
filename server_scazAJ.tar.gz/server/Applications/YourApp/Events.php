<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */

/**
 * 用于检测业务代码死循环或者长时间阻塞等问题
 * 如果发现业务卡死，可以将下面declare打开（去掉//注释），并执行php start.php reload
 * 然后观察一段时间workerman.log看是否有process_timeout异常
 */

//declare(ticks=1);
use \GatewayWorker\Lib\Gateway;

require_once("ReceptionZd.php");
require_once("functions.php");
require_once("ReceptionScreen.php");
require_once("Cache.php");

/**
 * 主逻辑
 * 主要是处理 onConnect onMessage onClose 三个方法
 * onConnect 和 onClose 如果不需要可以不用实现并删除
 */
class Events
{
    /**
     * 当客户端连接时触发
     * 如果业务不需此回调可以删除onConnect
     *
     * @param int $client_id 连接id
     */
    public static function onConnect($client_id)
    {

        //Gateway::sendToGroup('listen',$client_id .':login.');
        // 向当前client_id发送数据
        //Gateway::sendToClient($client_id, "Hello $client_id\n");
        // 向所有人发送
        //Gateway::sendToAll("$client_id login\n");
    }

    /**
     * 当客户端发来消息时触发
     * @param int $client_id 连接id
     * @param mixed $message 具体消息
     */
    public static function onMessage($client_id, $message)
    {


        echo "\n\n {$client_id}【" . date("Y-m-d H:i:s") . "】" . $message;
        if ($message == 'listen') {
            Gateway::joinGroup($client_id, 'listen');
            $Count = Gateway::getAllClientCount();
            $Group = Gateway::getClientCountByGroup('listen');
            Gateway::sendToGroup('listen', $client_id . '->登陆成功，目前在线终端：' . $Count . '个，其中监听终端：' . $Group . '个。');
            return;
        }

        //判断是否为指令
        if ('CMD:' == substr($message, 0, 4)) {
//            p1: 命令
//            p2: 时间戳
//            p3: 加密值
//            p4: 设备号
//            p5: 电池号
//            p6: 锁孔
//            p7: 流水号
            echo '指令';
            $link_id = $client_id;
            $jsonStr = substr($message, 4);
            $data = json_decode($jsonStr, true);
            if (!is_array($data) || count($data) < 4) {
                echo ' 参数错误';
                Gateway::sendToClient($link_id, '请求失败！连接将关闭！');
                return;
            }
            $config = include("config.php");
            $secret = $config['secret_key'];
            if (md5($secret . $data['p2']) != $data['p3']) {
                echo ' 签名错误';
                Gateway::sendToClient($link_id, '请求失败！连接将关闭！');
                return;
            }

            !isset($data['aims']) && $data['aims'] = 0;//主板编号
            $params = [
                'cmd' => $data['p1'],
                'device_id' => $data['p4'],
                'battery_id' => $data['p5'],
                'lock_id' => $data['p6'],
                'oid' => $data['p7'],
                'aims' => $data['aims'],
            ];
            isset($data['url']) && $params['url'] = $data['url'];
            isset($data['volume']) && $params['volume'] = $data['volume'];
            $client_id = Gateway::getClientIdByUid($params['device_id']);//array
            empty($client_id) && $client_id = '';
            if (is_array($client_id)) {
                $client_id = $client_id[0];
            }
            if (!$client_id) {
                echo '连接不存在';
                Gateway::sendToClient($link_id, '请求失败！连接将关闭！');
                return;
            }
            $sess = Gateway::getSession($client_id);
            if (!$sess) {
                echo 'session不存在';
                Gateway::sendToClient($link_id, '请求失败！连接将关闭！');
                return;
            }

			if ('zd' == $sess['type']) {
                $receptionEvents = new \Application\YourApp\ReceptionZd();
            }else if ('screen' == $sess['type']) {
				$receptionEvents = new \Application\YourApp\ReceptionScreen();
			}else {
                echo '找不到机型';
                return;
            }
            $receptionEvents->processCommand($client_id, $params);
            return;
        }

        //中电机型
        $preg = "/#\*(.*?)\*#/";
        preg_match_all($preg, $message, $match);
        if (isset($match[1]) && !empty($match[1])) {
            $receptionEvents = new \Application\YourApp\ReceptionZd();
            foreach ($match[1] as $message) {
                $message = json_decode($message, true);
                $receptionEvents->process($client_id, $message);
            }
            return;
        }
        
		//屏幕
		$preg = "/\\$##(.*?)##\\$/";
		preg_match_all($preg, $message, $match);
		if (isset($match[1]) && !empty($match[1])) {
			$receptionEvents = new \Application\YourApp\ReceptionScreen();
			foreach ($match[1] as $message) {
				$message = json_decode($message, true);
				$receptionEvents->process($client_id, $message);
			}
			return;
		}
		$message = @trim($message);
      	if('OK' == $message || '' == $message){
			return;
        }
		error_log($message."\n", 3, 'error.log');
    }

    /**
     * 当用户断开连接时触发
     * @param int $client_id 连接id
     */
    public static function onClose($client_id)
    {
        echo "\n {$client_id} onClose ";
        $storage = new \Application\YourApp\Cache();
        $prefix = "C:";
        //error_log($client_id."\n", 3, 'close.log');
        $cache = $storage->get($prefix.$client_id);
        if(!$cache || !is_array($cache)){
            return;
        }
        //error_log(print_r($cache,1)."\n", 3, 'close.log');
        $data = [ 'client_id'=>$client_id ];
        $res = curl('logout', $data);  //给服务器发送消息
//        GateWay::sendToGroup('listen',"$client_id logout->服务器返回消息-> $res");
        //GateWay::sendToGroup('listen',"$client_id logout");
    }

}
