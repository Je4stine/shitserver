<?php

namespace Application\YourApp;

use \GatewayWorker\Lib\Gateway;

require_once("functions.php");
require_once("Cache.php");
error_reporting(E_ALL^E_NOTICE);
/**
 * 中电响应
 * @package Application\YourApp
 */
class ReceptionZd
{

    //根据机柜发送过来的消息判断消息类型，并转交到相应的方法处理
    public function process($client_id, $message)
    {
        // 根据类型执行不同的业务
        !isset($message['cmd']) && $message['cmd'] = '';
        echo "\n {$message['cmd']} \n";
        $data = $message['data'];
        $data = array_merge($message, $data);
        switch ($message['cmd']) {
            case 'login': //设备注册
                self::login($client_id, $data);
                break;
            case 'heart': // 心跳响应
                self::heartbeat($client_id, $data);
                break;
            case 'detailup': //主动上报明细
                self::detailup($client_id, $data);
                break;
            case 'detail': // 明细
                self::stockDetail($client_id, $data);
                break;
            case 'rent': // 借充电宝出响应
                self::BorrowDevice($client_id, $data);
                break;
            case 'return': // 归还响应
                self::ReturnBattery($client_id, $data);
                break;
            case 'force': // 强弹
                self::forcePop($client_id, $data);
                break;
            case 'updata': // 升级
                self::updata($client_id, $data);
                break;
            case 'reboot': // 重启
                self::reboot($client_id, $data);
                break;
        }
    }

    public static function login($client_id, $message)
    {
        $cabinet_id = $message['sn'];
        $md5 = $message['md5'];

        $data = [];
        $data['cabinet_id'] = $cabinet_id;
        $data['client_id'] = $client_id;
        $data['md5'] = $md5;
        $data['ccid'] = $message['ccid'];
        $data['type'] = 'zd';
        $data['ip'] = $_SERVER['REMOTE_ADDR'];
        $data['soft_version'] = $message['fw'];
        $data['hard_version'] = $message['hd'];
      	$data['hard_type'] = $message['type'];
      	!isset($message['csq']) && $message['csq'] = 25;
      	!isset($message['bn']) && $message['bn'] = 1;
      
        $data['signal'] = $message['csq'];
        $data['bn'] = intval($message['bn']);




        $params['heart'] = 45;
        //登录
        $result = curl('login', $data);  //给服务器返回消息，服务器把信息存进缓存中
        	print_r($result );
        if (1 != $result['status']) {
            echo '登陆失败';
            saveLog($client_id, $cabinet_id, 2, '登录失败', $message, $result);
            saveLog($client_id, $cabinet_id, 2, '登录失败', $result, $result);
            error_log(print_r($result, 1), 3, 'error.log');


            self::sendCommand($client_id, 'login', ['r' => 1]);

            Gateway::sendToGroup('listen', $cabinet_id . '->登陆失败,md5:' . $md5 . ',msg' . $result['msg']);
            Gateway::closeClient($client_id);
            return;
        }

        if ($result['upgrade'] == 'true') {
            echo '升级' . $result['url'];
            self::sendCommand($client_id, 'login', ['r' => 1]);
            sleep(3);
            $content = self::sendCommand($client_id, 'updata', ['mode' => 'http', 'url' => $result['url']]);
            saveLog($client_id, $cabinet_id, 1, '升级', $message, $content);
            return;
        }

        echo '登陆成功';
        print_r($result);

        //解绑原有的
        $clients = Gateway::getClientIdByUid($cabinet_id);
        if (is_array($clients) && !empty($clients)) {
            foreach ($clients as $v) {
                Gateway::unbindUid($v, $cabinet_id);
                Gateway::closeClient($v);
            }
        }

        echo " $cabinet_id 绑定 $client_id";
        Gateway::bindUid($client_id, $cabinet_id);
        Gateway::setSession($client_id, ['cabinet_id' => $cabinet_id, 'type' => 'zd', 'code' => $result['ocode']]);
        
        //绑定连接
        $prefix = "C:";
        $storage = new \Application\YourApp\Cache();
        $cache = ['code'=>$result['ocode'], 'cabinet_id'=>$cabinet_id];
      	$storage->set($prefix.$cabinet_id, $cache,100);
        
        
        //云喇叭
        
        $yun = [
                'GT042011240002' =>[
                    'devicename'=> 'YS201225001000001',
                    'devicesecret'=> '761506894439e186c6e46dd905557343',
                    'productkey'=> 'a1aIoYsthkx',
                    ],
                'GT042011240003' =>[
                    'devicename'=> 'YS201225001000002',
                    'devicesecret'=> 'f5ad02bd0b41c573158e7fc93d662514',
                    'productkey'=> 'a1aIoYsthkx',
                    ],
                 'GT042011240004' =>[
                    'devicename'=> 'YS201225001000003',
                    'devicesecret'=> '789d83dacad01f3c88d735c321c117da',
                    'productkey'=> 'a1aIoYsthkx',
                    ],
            ];
        if(isset($message['yunspeaker']) && empty($message['devicename']) && isset($yun[$cabinet_id])){
            $params['devicename'] = $yun[$cabinet_id]['devicename'];
            $params['devicesecret'] = $yun[$cabinet_id]['devicesecret'];
            $params['productkey'] = $yun[$cabinet_id]['productkey'];
        }



        $params['r'] = 0;
        $content = self::sendCommand($client_id, 'login', $params);

        saveLog($client_id, $cabinet_id, 2, '登录', $message, $content);
        Gateway::sendToGroup('listen', $cabinet_id . '->登陆成功,md5:' . $md5);


    }


    //发送指令

    public static function sendCommand($client_id, $cmd, $data, $aims = 0)
    {
        $params = [
            'cmd' => $cmd,
        ];
        if (!isset($data['msgack']) || empty($data['msgack'])) {
            $params['msg'] = date("is") . mt_rand(10, 99);//业务流水
        } else {
            $params['msg'] = $data['msgack'];
            unset($data['msgack']);
        }

        $params['msg'] = intval($params['msg']);
        $params['data'] = $data;
        $params['aims'] = $aims;

        $content = "#*" . json_encode($params, JSON_UNESCAPED_UNICODE) . "*#";
        $content = str_replace("\\/", "/", $content);
        self::output(" cmd:$content");
        Gateway::sendToClient($client_id, $content);
        return $content;
    }


    //注册

    public static function output($content)
    {
        echo " {$content} ;";
    }


	//心跳
    public static function heartbeat($client_id, $message)
    {
        echo ' heartbeat ';

        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        self::sendCommand($client_id, 'heart', ['int' => $message['int']]);
        $cabinet_id = $sess['cabinet_id'];
      
        echo $cabinet_id;

        $data['cabinet_id'] = $cabinet_id;  //机柜ID
        $data['ip'] = $_SERVER['REMOTE_ADDR'];
        $data['client_id'] = $client_id;
        $data['signal'] = $message['csq'];
        $data['hex'] = '';

        $prefix = "E:";
        $storage = new \Application\YourApp\Cache();
        $cache = $storage->get($prefix.$cabinet_id);
        $cache['is_online'] = true;
        $cache['heart_time'] = time();
        $cache['signal'] = $data['signal'];
      
      	$storage->set($prefix.$cabinet_id, $cache,86400 * 3);
        $storage->handler->rPush('heart:chile', $cabinet_id); 
        
        
        //链接
        $prefix = "C:";
        $cache = ['code'=>$sess['code'], 'cabinet_id'=>$cabinet_id];  
        $storage->set($prefix.$client_id, $cache,100);

      	saveLog($client_id, $cabinet_id, 2, '心跳', $message, $message);
        Gateway::sendToGroup('listen', $cabinet_id . '->心跳');
    }



    //获取session
    public static function getSession($client_id)
    {
        $sess = Gateway::getSession($client_id);
        if (!isset($sess['cabinet_id'])) {
            echo "\n\n找不到session,断开连接";
            Gateway::closeClient($client_id);
            Gateway::sendToGroup('listen', $client_id . '->找不到session,断开连接');
            return false;
        }
        return $sess;
    }

    public static function detailup($client_id, $message)
    {
        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        $aims = isset($message['aims']) ? intval($message['aims']):0;
        $cabinet_id = $sess['cabinet_id'];
        $code = $sess['code'];
        $details = self::_stockDetails($message['d'], $cabinet_id, $code, $aims);
        //print_r($details);
        $content = self::sendCommand($client_id, 'detailup', ['r' => 0]);
        saveLog($client_id, $cabinet_id, 2, '更新库存', $message, $content);
        Gateway::sendToGroup('listen', $cabinet_id . "->库存明细: {$details}");
    }

    //设备明细

    private static function _stockDetails($info, $cabinet_id, $code, $aims = 1)
    {
        !is_array($info) && $info = [];
        $details = [];
        foreach ($info as $v) {
            if (empty($v['s'])) {
                continue;
            }
            $lockid = $v['n'];
            $power = (1 + intval($v['e'])) * 10;
            $power > 100 && $power = 100;
            $isBug = 0;
            $v['s'] != 1 && $isBug = 1;
            $details[$lockid] = array(
                'battery_id' => $v['sn'], //充电宝id
                'power' => $power, //电量级别
                'fault' => $isBug //是否故障
            );
        }
        $data = [];
        $data['cabinet_id'] = $cabinet_id;  //机柜ID
        $data['stock_num'] = count($details);
        $data['details'] = json_encode($details, JSON_UNESCAPED_UNICODE);
        $data['hex'] = $hex = '';
        $data['aims'] = $aims;

        curl('stockDetail', $data, $code);
        return $data['details'];
    }


    //设备明细
    public static function stockDetail($client_id, $message)
    {
        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        $aims = intval($message['aims']);
        $cabinet_id = $sess['cabinet_id'];
        $code = $sess['code'];
        $details = self::_stockDetails($message['d'], $cabinet_id, $code, $aims);
        print_r($details);

        saveLog($client_id, $cabinet_id, 2, '更新库存', $message, null);
        Gateway::sendToGroup('listen', $cabinet_id . "->库存明细: {$details}");
    }

    //借出
    public static function borrowDevice($client_id, $message)
    {
        $finally = $message['r'];
        $finally = ('0' == $finally) ? 1 : 0;
        $params = [];
        $params['status'] = $finally;
        $params['lock_id'] = intval($message['n']);
        $aims = intval($message['aims']);

        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        $cabinet_id = $sess['cabinet_id'];
        $code = $sess['code'];
        
        if($aims>1){//多板
        	$params['lock_id'] = $params['lock_id']+($aims -1)*12;
        }

        $data['cabinet_id'] = $cabinet_id;  //机柜ID
        $data['lock_id'] = $params['lock_id']; //锁ID
        $data['finally'] = $finally;  //结果
        $data['aims'] = $aims;
        $data['hex'] = '';
        $data['error'] = '';

        saveLog($client_id, $cabinet_id, 2, '借出充电宝', $message, null);
        curl('borrowDevice', $data, $code);

        $text = "状态 {$params['status']},锁孔{$params['lock_id']}}";
        Gateway::sendToGroup('listen', $cabinet_id . "->借出回调: {$text}");
        self::_stockDetails($message['d'], $cabinet_id, $code, $aims);

    }


    //归还
    public static function returnBattery($client_id, $message)
    {
        $params = [];
        $params['lock_id'] = intval($message['n']);
        $params['battery_id'] = $message['sn'];
        $aims = intval($message['aims']);

        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        $cabinet_id = $sess['cabinet_id'];
        $code = $sess['code'];
        
        if($aims>1){//多板
        	$params['lock_id'] = $params['lock_id']+($aims -1)*12;
        }

        $data = ['cabinet_id' => $cabinet_id];  //机柜ID
        $data['battery_id'] = $params['battery_id'];  //充电宝ID
        $data['lock_id'] = $params['lock_id'];
        $data['producer'] = 'zd';
        $data['aims'] = $aims;
        $result = curl('returnBattery', $data, $code);//给服务器返回消息
        $finally = (1 == $result['status']) ? 0 : 1;
        $content = self::sendCommand($client_id, 'return', ['r' => $finally, 'n' => $params['lock_id']], $aims);

        saveLog($client_id, $cabinet_id, 2, '归还充电宝', $message, $content);

        $text = "锁孔{$params['lock_id']},充电宝{$params['battery_id']}, 结果 {$result['msg']}";
        Gateway::sendToGroup('listen', $cabinet_id . "->归还: {$text}");

        if (1 == $result['status']) {
            self::_stockDetails($message['d'], $cabinet_id, $code, $aims);
        }
    }

    //强弹
    public static function forcePop($client_id, $message)
    {
        $finally = $message['r'];
        $params = [];
        $params['status'] = (0 === $finally) ? 1 : 0;
        $params['lock_id'] = (int)$message['n'];
        $aims = intval($message['aims']);

        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        $cabinet_id = $sess['cabinet_id'];
        $code = $sess['code'];

        $params['lock_id'] = intval($params['lock_id']);
        if($aims>1){//多板
        	$params['lock_id'] = $params['lock_id']+($aims -1)*12;
        }
        

        $data = [];
        $data['cabinet_id'] = $cabinet_id;  //机柜ID
        $data['finally'] = $params['status'];
        $data['lock_id'] = $params['lock_id'];
        $data['aims'] = $aims;
        $data['hex'] = $hex = '';


        curl('maintain', $data, $code);
        saveLog($client_id, $cabinet_id, 2, '弹出充电宝', $message, null);
        $text = "锁孔{$params['lock_id']},结果{$params['status']}";
        Gateway::sendToGroup('listen', $cabinet_id . "->强弹回调: {$text}");
        //机柜库存明细

        self::_stockDetails($message['d'], $cabinet_id, $code, $aims);
    }


    //升级
    public static function updata($client_id, $message)
    {
        $finally = $message['r'];
        $params = [];
        $params['status'] = (0 === $finally) ? 1 : 0;


        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        $cabinet_id = $sess['cabinet_id'];

        $data = [];
        $data['cabinet_id'] = $cabinet_id;  //机柜ID
        $data['finally'] = $finally;
        $data['hex'] = $hex = '';

        curl('updata', $data, $sess['code']);
        saveLog($client_id, $cabinet_id, 2, '升级响应', $message, null);
        $text = "结果{$params['status']}";
        Gateway::sendToGroup('listen', $cabinet_id . "->升级回调: {$text}");
    }

    //重启
    public static function reboot($client_id, $message)
    {
        $finally = $message['r'];
        $params = [];
        $params['status'] = (0 === $finally) ? 1 : 0;


        $sess = self::getSession($client_id);
        if (!$sess) {
            return;
        }
        $cabinet_id = $sess['cabinet_id'];

        $data = [];
        $data['cabinet_id'] = $cabinet_id;  //机柜ID
        $data['finally'] = $finally;
        $data['hex'] = $hex = '';

        curl('restart', $data, $sess['code']);
        saveLog($client_id, $cabinet_id, 2, '重启响应', $message, null);
        $text = "结果{$params['status']}";
        Gateway::sendToGroup('listen', $cabinet_id . "->重启回调: {$text}");

    }

    public function processCommand($client_id, $params)
    {
        $lock_id = (int)$params['lock_id'];
        $result = null;
        $type = '';
        switch ($params['cmd']) {
            case '111'://查询机柜库存明细
                Gateway::sendToGroup('listen', $params['device_id'] . "->发送指令: 查询机柜库存明细");
                $result = self::sendCommand($client_id, 'detail', ['n' => 0, 'msgack' => $params['oid']]);
                $type = '查询机柜库存明细';
                break;
            case '200': //借出
                Gateway::sendToGroup('listen', $params['device_id'] . "->发送指令: 借出锁孔 $lock_id");
                $result = self::sendCommand($client_id, 'rent', ['n' => $lock_id, 'msgack' => $params['oid']], $params['aims']);
                $type = '借出';
                break;
            case '203'://重启
                Gateway::sendToGroup('listen', $params['device_id'] . "->发送指令: 重启");
                $result = self::sendCommand($client_id, 'reboot', ['dev' => 0, 'msgack' => $params['oid']]);
                $type = '重启';
                break;
            case '204': //升级
                Gateway::sendToGroup('listen', $params['device_id'] . "->发送指令: 升级");
                $result = self::sendCommand($client_id, 'updata', ['mode' => 'http', 'url' => $params['url'], 'msgack' => $params['oid']]);
                $type = '升级';
                break;
            case '250': //弹出
                Gateway::sendToGroup('listen', $params['device_id'] . "->发送指令: 弹出锁孔 $lock_id");
                $result = self::sendCommand($client_id, 'force', ['n' => $lock_id, 'msgack' => $params['oid']], $params['aims']);
                $type = '强制弹出';
                break;
            case 'volume': //音量
                //Gateway::sendToGroup('listen', $params['device_id'] . "->发送指令: 弹出锁孔 $lock_id");
                $val = intval($params['volume']);
                $val < 1 && $val = 1;
                $val > 100 && $val = 100;
                $result = self::sendCommand($client_id, 'vol', ['n' => $val, 'r' =>  1]);
                $type = '设置音量';
                break;
        }
        if ($result) {
            saveLog($client_id, $params['device_id'], 1, $type, '', $result);
        }
    }

}