<?php
use \Workerman\Worker;
use \Workerman\WebServer;
use \GatewayWorker\Gateway;
use \GatewayWorker\BusinessWorker;
use \Workerman\Autoloader;

// #### 内部推送端口(假设当前服务器内网ip为192.168.100.100) ####
//$internal_gateway = new Gateway("Text://10.104.235.47:7273");

$context = array(
		    'ssl' => array(
			            'local_cert'  =>   '/www/server/panel/vhost/cert/server.gobattery.cl/fullchain.pem',
	                    'local_pk'    =>   '/www/server/panel/vhost/cert/server.gobattery.cl/privkey.pem',
                        'verify_peer' => false
                )
	    );
$internal_gateway = new Gateway("Websocket://0.0.0.0:7272", $context);
$internal_gateway->transport = 'ssl';


$internal_gateway->name='listenGateway';
$internal_gateway->startPort = 4000;
$internal_gateway->lanIp = '127.0.0.1';
// 端口为start_register.php中监听的端口，聊天室默认是1238
$internal_gateway->registerAddress = '127.0.0.1:1239';
// #### 内部推送端口设置完毕 ####

if(!defined('GLOBAL_START'))
{
    Worker::runAll();
}