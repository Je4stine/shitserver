<?php
return [
   'service_url' => 'http://cdb.mapro.co.ke/cloud/Reception/', //网站域名
   'secret_key' => 'mapro@zdhx2022'  //通信密钥，与管理后台配置headerkey一致
];

